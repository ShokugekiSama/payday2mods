local old_init = old_init or HudIconsTweakData.init
function HudIconsTweakData:init()
	self.gage_assignment = {
		texture = "guis/dlcs/gage_pack_jobs/textures/pd2/endscreen/gage_assignment",
		texture_rect = { 0, 0, 128, 128 }
	}
	old_init(self)
end