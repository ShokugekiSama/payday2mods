function HUDManager:gagemk_add_waypoint(id, data)
	if self._hud.waypoints[id] then
		self:remove_waypoint(id)
	end

	local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2)

	if not hud then
		self._hud.stored_waypoints[id] = data

		return
	end

	local waypoint_panel = hud.panel
	local icon = data.icon or "wp_standard"
	local text = ""
	local icon, texture_rect = tweak_data.hud_icons:get_icon_data(icon, {
		0,
		0,
		32,
		32
	})
	local bitmap = waypoint_panel:bitmap({
		layer = 0,
		rotation = 360,
		name = "bitmap" .. id,
		texture = icon,
		texture_rect = texture_rect,
		color = data.color or Color.white,
		w = data.size and data.size[1] or texture_rect[3],
		h = data.size and data.size[2] or texture_rect[4],
		blend_mode = data.blend_mode
	})
	local arrow_icon, arrow_texture_rect = tweak_data.hud_icons:get_icon_data("wp_arrow")
	local arrow = waypoint_panel:bitmap({
		layer = 0,
		visible = false,
		rotation = 360,
		name = "arrow" .. id,
		texture = arrow_icon,
		texture_rect = arrow_texture_rect,
		color = (data.color or Color.white):with_alpha(0.75),
		w = data.size and data.size[1] or arrow_texture_rect[3],
		h = data.size and data.size[2] or arrow_texture_rect[4],
		blend_mode = data.blend_mode
	})
	local distance = nil

	if data.distance then
		distance = waypoint_panel:text({
			vertical = "center",
			h = 24,
			w = 128,
			align = "center",
			text = "16.5",
			rotation = 360,
			layer = 0,
			name = "distance" .. id,
			color = data.color or Color.white,
			font = tweak_data.hud.medium_font_noshadow,
			font_size = tweak_data.hud.default_font_size * 0.5,
			blend_mode = data.blend_mode
		})

		distance:set_visible(false)
	end

	local timer = data.timer and waypoint_panel:text({
		font_size = 32,
		h = 32,
		vertical = "center",
		w = 32,
		align = "center",
		rotation = 360,
		layer = 0,
		name = "timer" .. id,
		text = (math.round(data.timer) < 10 and "0" or "") .. math.round(data.timer),
		font = tweak_data.hud.medium_font_noshadow
	})
	text = waypoint_panel:text({
		h = 24,
		vertical = "center",
		w = 512,
		align = "center",
		rotation = 360,
		layer = 0,
		name = "text" .. id,
		text = utf8.to_upper(" " .. text),
		font = tweak_data.hud.small_font,
		font_size = tweak_data.hud.small_font_size
	})
	local _, _, w, _ = text:text_rect()

	text:set_w(w)

	local w, h = bitmap:size()
	self._hud.waypoints[id] = {
		move_speed = 1,
		init_data = data,
		state = data.state or "present",
		present_timer = data.present_timer or 2,
		bitmap = bitmap,
		arrow = arrow,
		size = Vector3(w, h, 0),
		text = text,
		distance = distance,
		timer_gui = timer,
		timer = data.timer,
		pause_timer = data.pause_timer or data.timer and 0,
		position = data.position,
		unit = data.unit,
		no_sync = data.no_sync,
		radius = data.radius or 160
	}
	self._hud.waypoints[id].init_data.position = data.position or data.unit:position()
	local slot = 1
	local t = {}

	for _, data in pairs(self._hud.waypoints) do
		if data.slot then
			t[data.slot] = data.text:w()
		end
	end

	for i = 1, 10 do
		if not t[i] then
			self._hud.waypoints[id].slot = i

			break
		end
	end

	self._hud.waypoints[id].slot_x = 0

	if self._hud.waypoints[id].slot == 2 then
		self._hud.waypoints[id].slot_x = t[1] / 2 + self._hud.waypoints[id].text:w() / 2 + 10
	elseif self._hud.waypoints[id].slot == 3 then
		self._hud.waypoints[id].slot_x = -t[1] / 2 - self._hud.waypoints[id].text:w() / 2 - 10
	elseif self._hud.waypoints[id].slot == 4 then
		self._hud.waypoints[id].slot_x = t[1] / 2 + t[2] + self._hud.waypoints[id].text:w() / 2 + 20
	elseif self._hud.waypoints[id].slot == 5 then
		self._hud.waypoints[id].slot_x = -t[1] / 2 - t[3] - self._hud.waypoints[id].text:w() / 2 - 20
	end
end