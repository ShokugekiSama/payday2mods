if not rawget(_G, "gage_marker") then
	rawset(_G, "gage_marker", {})

	gage_marker.marker_color = Color.blue:with_alpha(0.25)
	gage_marker.toggle_mark = false;

	gage_marker.markers = {
		gage_assignment =	{	icon = "gage_assignment", distance = true	},
	}

	function gage_marker:mark()
		self.toggle_mark = not self.toggle_mark
		for tweak_id, tweak_data in pairs(self.markers) do
			for _, unit in pairs(managers.interaction._interactive_units) do
				if unit:interaction().tweak_data == tweak_id then
					if self.toggle_mark then
						managers.hud:gagemk_add_waypoint(tostring( unit:key() ),
						{ 
							icon = tweak_data.icon or 'wp_standard',
							size = tweak_data.size or {20, 20},
							distance = tweak_data.distance or false,
							position = unit:position(),
							no_sync = true,
							present_timer = 0,
							state = "present",
							radius = tweak_data.radius or 500,
							color = tweak_data.color or self.marker_color,
							blend_mode = "add"
						})	
					else
						managers.hud:remove_waypoint(tostring( unit:key() ))
					end
				end
			end
		end
		local debug_msg = self.toggle_mark and "MARKED" or "UNMARKED"
		local debug_color = self.toggle_mark and Color.green or Color.red
		managers.mission._fading_debug_output:script().log('Gage Packages - '..debug_msg, debug_color)
	end
	gage_marker:mark()
else
	gage_marker:mark()
end