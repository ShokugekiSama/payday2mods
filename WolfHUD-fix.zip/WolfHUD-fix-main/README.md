# WolfHUD-fix
Fix of [WolfHUD](https://github.com/Kamikaze94/WolfHUD) by Kamikaze94
